# Developer Daily Summary App

## Frontend (React Native with Expo)
- Install dependencies: `npm install`
- Run app: `npm start`

## Backend (Firebase Functions)
- Install Firebase Tools: `npm install -g firebase-tools`
- Login to Firebase: `firebase login`
- Deploy functions: `firebase deploy --only functions`
