const functions = require('firebase-functions');
const gmailService = require('./services/gmailService');
const jiraService = require('./services/jiraService');
const graniteService = require('./services/graniteService');

exports.getDailySummary = functions.https.onRequest(async (req, res) => {
  const tasks = await gmailService.fetchTasks();
  const releases = await jiraService.fetchReleases();
  const summary = await graniteService.summarize(tasks, releases);
  res.json(summary);
});
