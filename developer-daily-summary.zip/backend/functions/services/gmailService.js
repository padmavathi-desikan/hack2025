exports.fetchTasks = async () => {
  // Placeholder for Gmail fetching logic
  return ["Task 1 from Gmail", "Task 2 from Gmail"];
};
