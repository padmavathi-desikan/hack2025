exports.fetchReleases = async () => {
  // Placeholder for Jira fetching logic
  return ["Release 1 from Jira", "Release 2 from Jira"];
};
